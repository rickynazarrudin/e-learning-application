package com.tekkom.meawapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.w3c.dom.Text;

import static android.widget.Toast.LENGTH_SHORT;

public class EditProfileActivity extends AppCompatActivity {

    String username, email, nrp, departemen, fullname;
    TextView userName, Email, Fullname;
    DatabaseReference user, emaill, fulln;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        Intent intent = getIntent();
        username = intent.getStringExtra("Username");
        nrp = intent.getStringExtra("NRP");
        email = intent.getStringExtra("Email");
        fullname = intent.getStringExtra("Fullname");
        departemen = intent.getStringExtra("Departemen");

        userName = (TextView)findViewById(R.id.studentUsername);
        Email = (TextView)findViewById(R.id.studentEmail);
        Fullname = (TextView)findViewById(R.id.studentFullname);
        update = (Button)findViewById(R.id.updateButton);

        userName.setText(username);
        Email.setText(email);
        Fullname.setText(fullname);

        username = userName.getText().toString();
        email = Email.getText().toString();
        fullname = Fullname.getText().toString();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Berhasil memperbarui data anda", LENGTH_SHORT).show();
            }
        });


    }
}
