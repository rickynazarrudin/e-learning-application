package com.tekkom.meawapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HasilQuizzActivity extends AppCompatActivity {

    TextView skorakhir, correctans;
    Button backhome, tryagain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_quizz);
        skorakhir = (TextView)findViewById(R.id.totalSkor);
        correctans = (TextView)findViewById(R.id.totalBenar);
        tryagain = (Button)findViewById(R.id.cobaLagi);

        tryagain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HasilQuizzActivity.this, StudentActivity.class);
                startActivity(intent);
            }
        });

        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            int score = extra.getInt("SCORE");
            int totalQuestion = extra.getInt("TOTAL");
            int correctAnswer = extra.getInt("CORRECT");

            skorakhir.setText(String.format("%d", score));
            correctans.setText(String.format("%d / %d", correctAnswer, totalQuestion));
        }

    }
}
