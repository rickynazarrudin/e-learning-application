package com.tekkom.meawapp;

public class Quiz {
    private String IDMateri, IDPertanyaan, answerA, answerB, answerC, answerD, correctAnswer, question;

    public Quiz(){
    }

    public Quiz(String IDMateri, String IDPertanyaan, String answerA, String answerB, String answerC, String answerD, String correctAnswer, String question) {
        this.IDMateri = IDMateri;
        this.IDPertanyaan = IDPertanyaan;
        this.answerA = answerA;
        this.answerB = answerB;
        this.answerC = answerC;
        this.answerD = answerD;
        this.correctAnswer = correctAnswer;
        this.question = question;
    }

    public String getIDMateri() {
        return IDMateri;
    }

    public void setIDMateri(String IDMateri) {
        this.IDMateri = IDMateri;
    }

    public String getIDPertanyaan() {
        return IDPertanyaan;
    }

    public void setIDPertanyaan(String IDPertanyaan) {
        this.IDPertanyaan = IDPertanyaan;
    }

    public String getAnswerA() {
        return answerA;
    }

    public void setAnswerA(String answerA) {
        this.answerA = answerA;
    }

    public String getAnswerB() {
        return answerB;
    }

    public void setAnswerB(String answerB) {
        this.answerB = answerB;
    }

    public String getAnswerC() {
        return answerC;
    }

    public void setAnswerC(String answerC) {
        this.answerC = answerC;
    }

    public String getAnswerD() {
        return answerD;
    }

    public void setAnswerD(String answerD) {
        this.answerD = answerD;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
