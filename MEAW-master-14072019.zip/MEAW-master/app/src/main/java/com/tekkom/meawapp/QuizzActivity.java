package com.tekkom.meawapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Collection;
import java.util.Collections;

public class QuizzActivity extends AppCompatActivity implements View.OnClickListener {

    final static long INTERVAL = 1000;
    final static long TIMEOUT = 10000;

    CountDownTimer countDownTimer;
    int index=0, score=0, thisQuestion=0, totalQuestion, correctAnswer, progressValue=0, timetot=10;
    ProgressBar progressBar;
    TextView tnamaMateri, pertanyaan, txtQuestionNum, waktusisa;
    ImageView timage;
    Button pilihanA, pilihanB, pilihanC, pilihanD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quizz);

        Intent intent = getIntent();
        final String namaMateri = intent.getStringExtra("namaMateri");
        final String image = intent.getStringExtra("image");
        final String IDMateri = intent.getStringExtra("IDMateri");

        tnamaMateri = (TextView)findViewById(R.id.student_quiz_title);
        pertanyaan = (TextView)findViewById(R.id.pertanyaanQuiz);
        waktusisa = (TextView)findViewById(R.id.timeLeft);
        txtQuestionNum = findViewById(R.id.txtTotalQuestion);
        timage = (ImageView)findViewById(R.id.student_quiz_thumbnail);
        pilihanA = (Button)findViewById(R.id.answerA);
        pilihanB = (Button)findViewById(R.id.answerB);
        pilihanC = (Button)findViewById(R.id.answerC);
        pilihanD = (Button)findViewById(R.id.answerD);
        progressBar = (ProgressBar)findViewById(R.id.progressBar);
        Collections.shuffle(Common.questionList);
        progressBar.getProgressDrawable().setColorFilter(Color.RED, android.graphics.PorterDuff.Mode.SRC_IN);
        pilihanA.setOnClickListener(this);
        pilihanB.setOnClickListener(this);
        pilihanC.setOnClickListener(this);
        pilihanD.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        countDownTimer.cancel();
        if(index < totalQuestion)
        {
            Button clickedButton = (Button) v;
            if(clickedButton.getText().equals(Common.questionList.get(index).getCorrectAnswer()))
            {
                //Toast.makeText(this, "BENAR - "+clickedButton.getText(), Toast.LENGTH_SHORT).show();
                score += 10;
                correctAnswer += 1;
            }else {
                //Toast.makeText(this, "SALAH - " + clickedButton.getText(), Toast.LENGTH_SHORT).show();
            }
            showQuestion(++index);
        }
    }
    private void showQuestion(int index){
        if(index < totalQuestion){
            thisQuestion++;
            txtQuestionNum.setText("Total Q: "+String.format("%d / %d", thisQuestion, totalQuestion));
            progressBar.setProgress(0);
            progressValue = 0;
            pertanyaan.setText("Q : "+Common.questionList.get(index).getQuestion());
            pilihanA.setText(Common.questionList.get(index).getAnswerA());
            pilihanB.setText(Common.questionList.get(index).getAnswerB());
            pilihanC.setText(Common.questionList.get(index).getAnswerC());
            pilihanD.setText(Common.questionList.get(index).getAnswerD());
            countDownTimer.start();
        }else{
            Intent intent = new Intent(this, HasilQuizzActivity.class);
            Bundle dataSend = new Bundle();
            dataSend.putInt("SCORE", score);
            dataSend.putInt("TOTAL", totalQuestion);
            dataSend.putInt("CORRECT", correctAnswer);
            intent.putExtras(dataSend);
            startActivity(intent);
            finish();
        }
    }
    @Override
    protected void onPostResume() {
        super.onPostResume();
        totalQuestion = Common.questionList.size();
        countDownTimer = new CountDownTimer(TIMEOUT, INTERVAL) {
            @Override
            public void onTick(long millisUntilFinished) {
                progressBar.setProgress(progressValue);
                waktusisa.setText("WAKTU SISA KAMU : "+String.format("%d", (timetot-progressValue))+"s");
                progressValue++;
            }
            @Override
            public void onFinish() {
                countDownTimer.cancel();
                showQuestion(++index);
            }
        };
        showQuestion(index);
    }
}
