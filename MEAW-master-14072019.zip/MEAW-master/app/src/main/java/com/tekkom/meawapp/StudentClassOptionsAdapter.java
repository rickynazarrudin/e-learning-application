package com.tekkom.meawapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Iterator;

public class StudentClassOptionsAdapter extends RecyclerView.Adapter<StudentClassOptionsAdapter.MyViewHolder>{

    Context context;
    ArrayList<StudentCourseContentSummary> studentCourseContentSummaries;
    DatabaseReference reference, referenceB;
    String currentNrp;

    public StudentClassOptionsAdapter(Context c, ArrayList<StudentCourseContentSummary> p) {
        context = c;
        studentCourseContentSummaries = p;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.content_recview_student_classoptions, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull StudentClassOptionsAdapter.MyViewHolder holder, int position) {
        final String fnamaMateri = studentCourseContentSummaries.get(position).getNamaMateri();
        final String fdeskripsi = studentCourseContentSummaries.get(position).getDeskripsi();
        final String fimage = studentCourseContentSummaries.get(position).getImage();
        final String ffileURL = studentCourseContentSummaries.get(position).getFileURL();
        final String fIDMateri = studentCourseContentSummaries.get(position).getIDMateri();
        holder.namaMateri.setText(fnamaMateri);
        Picasso.get().load(studentCourseContentSummaries.get(position).getImage()).into(holder.imageMateri);
        holder.imageMateri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder abuilder = new AlertDialog.Builder(context);
                abuilder.setMessage("Anda yakin ingin menambahkan "+fnamaMateri+" dalam daftar kursus anda?")
                        .setCancelable(false)
                        .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                FirebaseFirestore.getInstance()
                                        .collection("users")
                                        .document(uid)
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot documentSnapshot = task.getResult();
                                                    if (documentSnapshot.exists()) {
                                                        //Toast.makeText(getContext(), "DocumentSnapshot data: " + documentSnapshot.getData(), Toast.LENGTH_SHORT).show();
                                                        currentNrp = documentSnapshot.getString("id");
                                                        reference = FirebaseDatabase.getInstance().getReference("MateriPengguna").child(currentNrp).child(fIDMateri);
                                                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                if(dataSnapshot.exists())
                                                                {
                                                                    Toast.makeText(context,"Anda sudah terdaftar!", Toast.LENGTH_SHORT).show();
                                                                }else {
                                                                    reference.setValue(fIDMateri);
                                                                    Toast.makeText(context,"Berhasil menambahkan "+fnamaMateri, Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                                            }
                                                        });
                                                    } else {
                                                        Toast.makeText(context, "No such a document", Toast.LENGTH_SHORT).show();
                                                    }
                                                } else {
                                                    Toast.makeText(context, "get failed with ", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = abuilder.create();
                alertDialog.setTitle("Tambahkan kursus");
                alertDialog.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return studentCourseContentSummaries.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView namaMateri;
        ImageView imageMateri;
        CardView cardView;

        public MyViewHolder(View itemView) {
            super(itemView);
            namaMateri = itemView.findViewById(R.id.student_classoptions_title);
            imageMateri = itemView.findViewById(R.id.student_classoptions_thumbnail);
            cardView = itemView.findViewById(R.id.card_view_student_classoptions);
        }
    }
}
