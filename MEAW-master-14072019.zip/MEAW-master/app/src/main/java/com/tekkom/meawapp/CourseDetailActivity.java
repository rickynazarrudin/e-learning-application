package com.tekkom.meawapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

public class CourseDetailActivity extends AppCompatActivity {

    String currentNRP;
    String IDMateri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);

        Intent intent = getIntent();
        final String namaMateri = intent.getStringExtra("namaMateri");
        String deskripsi = intent.getStringExtra("deskripsi");
        String image = intent.getStringExtra("image");
        final String fileURL = intent.getStringExtra("fileURL");
        IDMateri = intent.getStringExtra("IDMateri");

        TextView tnamaMateri = findViewById(R.id.namaMateri);
        TextView tdeskripsi = findViewById(R.id.deskripsiMateri);
        ImageView timage = findViewById(R.id.backDetail);
        Button buttonLearn = (Button)findViewById(R.id.lihatMateri);
        Button buttonStop = (Button)findViewById(R.id.berhentiMateri);

        tnamaMateri.setText(namaMateri);
        tdeskripsi.setText(deskripsi);
        Picasso.get().load(image).into(timage);

        buttonLearn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), LearnActivity.class);
                i.putExtra("fileURL", fileURL);
                i.putExtra("namaMateri", namaMateri);
                startActivity(i);
            }
        });

        buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder abuilder = new AlertDialog.Builder(CourseDetailActivity.this);
                abuilder.setMessage("Anda yakin ingin berhenti pada kursus "+namaMateri+" ?")
                        .setCancelable(false)
                        .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //yes
                                String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                FirebaseFirestore.getInstance()
                                        .collection("users")
                                        .document(uid)
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot documentSnapshot = task.getResult();
                                                    if (documentSnapshot.exists()) {
                                                        //Toast.makeText(getContext(), "DocumentSnapshot data: " + documentSnapshot.getData(), Toast.LENGTH_SHORT).show();
                                                        currentNRP = documentSnapshot.getString("id");
                                                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                                                        DatabaseReference myRef = database.getReference("MateriPengguna").child(currentNRP);
                                                        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                                for (DataSnapshot stock : dataSnapshot.getChildren()) {
                                                                    if(stock.getValue().equals(IDMateri))
                                                                        stock.getRef().removeValue();
                                                                    Toast.makeText(getApplicationContext(), "Berhasil berhenti kursus "+namaMateri, Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                            @Override
                                                            public void onCancelled(DatabaseError error) {
                                                                // Failed to read value
                                                            }
                                                        });
                                                    } else {
                                                        Toast.makeText(getApplicationContext(), "No such a document", Toast.LENGTH_SHORT).show();
                                                    }
                                                } else {
                                                    Toast.makeText(getApplicationContext(), "Get failed  ", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //no
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = abuilder.create();
                alertDialog.setTitle("Berhenti kursus");
                alertDialog.show();
            }
        });
    }
}
