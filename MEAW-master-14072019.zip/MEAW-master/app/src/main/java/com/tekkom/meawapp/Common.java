package com.tekkom.meawapp;

import com.tekkom.meawapp.Quiz;

import java.util.ArrayList;
import java.util.List;

public class Common {
    public static String IDMateri;
    public static List<Quiz> questionList = new ArrayList<>();
}
