package com.tekkom.meawapp;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class StudentQuizzAdapter extends RecyclerView.Adapter<StudentQuizzAdapter.MyViewHolder> {

    Context context;
    ArrayList<StudentCourseContentSummary> studentCourseContentSummaries;

    public StudentQuizzAdapter(Context c, ArrayList<StudentCourseContentSummary> p){
        context = c;
        studentCourseContentSummaries = p;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.content_recview_student_quiz, parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull StudentQuizzAdapter.MyViewHolder holder, int position) {
        final String fnamaMateri = studentCourseContentSummaries.get(position).getNamaMateri();
        final String fdeskripsi = studentCourseContentSummaries.get(position).getDeskripsi();
        final String fimage = studentCourseContentSummaries.get(position).getImage();
        final String ffileURL = studentCourseContentSummaries.get(position).getFileURL();
        final String fIDMateri = studentCourseContentSummaries.get(position).getIDMateri();
        holder.namaMateri.setText(fnamaMateri);
        Picasso.get().load(studentCourseContentSummaries.get(position).getImage()).into(holder.imageMateri);
        holder.imageMateri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context1 = v.getContext();
                Intent intent = new Intent(context1, AreYouReadyActivity.class);
                intent.putExtra("namaMateri", fnamaMateri);
                intent.putExtra("image", fimage);
                intent.putExtra("IDMateri", fIDMateri);
                Snackbar.make(v, "Clicked element " + fnamaMateri, Snackbar.LENGTH_LONG).show();
                context1.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return studentCourseContentSummaries.size();
    }
    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView namaMateri;
        ImageView imageMateri;
        CardView cardView;

        public  MyViewHolder(View itemView){
            super(itemView);
            imageMateri = itemView.findViewById(R.id.student_quiz_thumbnail);
            namaMateri = itemView.findViewById(R.id.student_quiz_title);
            cardView = itemView.findViewById(R.id.card_view_student_quiz);
        }
    }
}
